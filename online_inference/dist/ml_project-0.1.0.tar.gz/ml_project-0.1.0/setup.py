#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from setuptools import find_packages, setup

setup(
    name="ml_project",
    packages=find_packages(),
    version="0.1.0",
    install_requires=[
        "pandas==1.1.3",
        "hydra-core==1.0.6",
        "pytest==6.2.3",
        "numpy==1.20.2",
        "python-dotenv>=0.5.1",
        "scikit-learn==0.24.2",
        "setuptools~=56.0.0",
        "omegaconf~=2.0.6",
    ],
    extras_requires=["jupyterlab==3.0.13", "pandas-profiling==2.11.0"],
    setup_requires=["pytest==6.2.3", "flake8"],
    description="Production-ready project for heart disease classification",
    author="Hanna Herasimchyk",
    license="MIT",
)
