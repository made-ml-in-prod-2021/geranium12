#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from ml_project.models import train_pipeline

__all__ = ["train_pipeline"]
