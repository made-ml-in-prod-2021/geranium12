#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from .utils import get_root_path

__all__ = ["get_root_path"]
